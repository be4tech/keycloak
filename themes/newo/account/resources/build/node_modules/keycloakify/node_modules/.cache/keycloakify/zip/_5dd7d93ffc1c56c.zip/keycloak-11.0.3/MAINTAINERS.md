Maintainers
===========

* [Stian Thorgersen](https://github.com/stianst) (project lead)
* [Bruno Oliveira da Silva](https://github.com/abstractj)
* [Hynek Mlnařík](https://github.com/hmlnarik)
* [Marek Posolda](https://github.com/mposolda)
* [Pavel Drozd](https://github.com/pdrozd)
* [Pedro Igor](https://github.com/pedroigor)
* [Stan Silvert](https://github.com/ssilvert)